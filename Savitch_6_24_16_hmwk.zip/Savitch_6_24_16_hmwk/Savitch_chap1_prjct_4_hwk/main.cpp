/* 
 * File:   main.cpp
 * Author: Eric Contreras
 *
 * Created on June 20, 2016, 6:54 PM
 * Purpose: Template
 */

//System Libraries
#include <iostream> //Input/Output Libary
#include <cmath>    //Math Libary
using namespace std;//Namespace of the System Libraries

//User Libraries

//Global Constants
const float GRAVITY=32.174f;//Acceleration sea level ft/sec/sec
//Function Prototypes

//Execution Begins Here!
/*
 * 
 */
int main(int argc, char** argv) {
    //Declare Variables
    float time;//time in seconds 
    float distance; // distance in feet
    //Input Data
    cout<<"input time for free fall in seconds"<<endl;
    cin>>time;
   //Process the Data
   //dstance 1/2*GRAVITY*time*time;//gives 0 because of int/int division
   //dstance=GRAVITY*TIME*TIME/2;
    distance= GRAVITY*time*time/2;
   //Output the processed Data
    cout<<"The distance dropped during "<<time<<"(secs) =";
    cout<<distance<<" (ft)"<<endl;
   
    
    
    //Exit Stage Right!
    return 0;
}


