/* 
 * File:   main.cpp
 * Author: Eric Contreras
 * Created on June 20, 2016, 6:51 PM
 * Purpose:  Template
 */

//System Libraries
#include <iostream>  //Input/Output Library
using namespace std; //Namespace of the System Libraries

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    char c;//character to utilize
    //Input Data
    cout<<"choose the letter to use in forming a Big C output"<<endl;
    cin>>c;
    //Process the Data
    
    //Output the processed Data
    cout<<"     "<<c<<"   "<<c<<" "<<c<<endl;
    cout<<"   "<<c<<"    "<<c<<" "<<c<<endl;
    cout<<"  "<<c<<endl;
    cout<<" "<<c<<endl;
    cout<<" "<<c<<endl;
    cout<<" "<<c<<endl;
    cout<<"  "<<c<<endl;
    cout<<"   "<<c<<"    "<<c<<" "<<c<<endl;
    cout<<"     "<<c<<"   "<<c<<" "<<c<<endl;
    //Exit Stage Right!
    return 0;
}