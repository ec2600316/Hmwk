
/* 
 * File:   main.cpp
 * Author: Eric Contreras
 * Created on June 22, 2016, 6:51 PM
 * Purpose:  Template
 */

//System Libraries
#include <iostream>  //Input/Output Library
using namespace std; //Namespace of the System Libraries

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    
    //Input Data
    
    //Process the Data
    cout<<"HELLO WORLD"<<endl;//phrases
    //Output the processed Data
    cout<<"Space on iostream"<<endl; //list of errors
    cout<<"caps on iostream"<<endl;
    cout<<"space on < iostream>"<<endl;
    cout<<"not havig namespace std"<<endl;
    cout<<"misspelling of cout"<<endl;
    cout<<"not having the correct<<"<<endl;
    cout<<"not having int main"<<endl;
    cout<<"not having the brakcets at the front and end"<<endl;
    cout<<"these are erros that will not allow for the program to compile"<<endl;
          
    //Exit Stage Right!
    return 0;
}