/* 
 * File:   main.cpp
 * Author: Eric Contreras
 * Created on June 22, 2016, 6:51 PM
 * Purpose:  Template
 */

//System Libraries
#include <iostream>  //Input/Output Library
using namespace std; //Namespace of the System Libraries

//User Libraries

//Global Constants
const float Quarter=25;
const float Nickel=5;
const float Dime=10; 
//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    float Quarter, Dime, Nickel, Cents;// variables 
    //Input Data
    cout<<"Hello, do you have some change for me please?"<<endl; // AMPM guy 
    cout<<"I need it to go to colorado, i just ran out of gas and have no way"<<endl;
    cout<<"to contact my family. How many quarters, dimes, and nickels can you give me?"<<endl;
    cout<<"QQ(SPACE) DD(SPACE) NN(SPACE)"<<endl;
    cin>>Quarter>>Dime>>Nickel;
    cout<<"Cool man you gave "<<Quarter<<" Quarters "<<Dime<<" Dimes "<<Nickel<<" Nickels "<<endl;
    
            
    Cents=(Quarter*25)+(Dime*10)+(Nickel*5);
    cout<<"Thanks Man!! You gave me "<<Cents<< " cents"<<endl;
    
    //Process the Data
    
    //Output the processed Data
    
    //Exit Stage Right!
    return 0;
}
