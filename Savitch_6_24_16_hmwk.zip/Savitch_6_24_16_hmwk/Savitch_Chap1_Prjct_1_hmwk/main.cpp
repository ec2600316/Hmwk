/* 
 * File:   main.cpp
 * Author: Eric Contreras
 * Created on June 22, 2016, 6:51 PM
 * Purpose:  Template
 */

//System Libraries
#include <iostream>  //Input/Output Library
using namespace std; //Namespace of the System Libraries

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    int A, B, C;
    //Input Data
    
    
          
    //Process the Data
    cout<<"Hello, Welcome user..."<<endl;
    
    cout<<"Enter the two integers, you would like me to calculate their sum and product."<<endl;
    cout<<"-> DDDDDDDDDD DDDDDDDD"<<endl;
    
    cin>>A>>B;
    cout<<"The sum of "<<endl;
    cout<<A;//show number 
    cout<<" and "<<endl;
    cout<<B;
    cout<<" is "<<endl;
    C=A+B; //addition result 
    cout<<C;
    
    cout<<" While the product is "<<endl;
    C=A*B;//product result
    cout<<C;//show number
    
     
    
    
    cout<<" Good-bye"<<endl;
     
    
    //Output the processed Data
    
    //Exit Stage Right!
    return 0;
}
