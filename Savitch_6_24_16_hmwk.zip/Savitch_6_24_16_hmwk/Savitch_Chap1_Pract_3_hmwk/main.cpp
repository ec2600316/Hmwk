/* 
 * File:   main.cpp
 * Author: Eric Contreras
 * Created on June 22, 2016, 6:51 PM
 * Purpose:  Template
 */

//System Libraries
#include <iostream>  //Input/Output Library
using namespace std; //Namespace of the System Libraries

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    int number_of_pods, peas_per_pod,total_peas;//variables 
    //Input Data
    
    //Process the Data
    cout<<"Hello, Welcome user..."<<endl;//phrases
    
    cout<<"Enter the number of pods"<<endl;
    
    cin>> number_of_pods;
    
    cout<<"Enter the number of peas in a pod"<<endl;
    cin>>peas_per_pod;
    total_peas= number_of_pods/peas_per_pod;
    cout<<"If you have ";
    cout<<number_of_pods;
    cout<<" pea pods ";
    cout<<"and ";
    cout<<peas_per_pod;
    cout<<" peas in each pod, then"<<endl;
    cout<<"you have ";
    cout<<total_peas;
    cout<<" peas in all the pods"<<endl;
    cout<<"Good-bye"<<endl;
     
    
    //Output the processed Data
    
    //Exit Stage Right!
    return 0;
}
