/* 
 * File:   main.cpp
 * Author: Eric Contreras
 * Created on June 22, 2016, 6:51 PM
 * Purpose:  Template
 */

//System Libraries
#include <iostream>  //Input/Output Library
using namespace std; //Namespace of the System Libraries

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    int Height, Length, Area, Width;  //variable
    //Input Data
    
    //Process the Data
    cout<<"Hello, Welcome user..."<<endl;//phrases
    
    cout<<"Enter the Area, Height and Width of the rectangular area you would like to fill with fencing."<<endl;
    
    cin>>Area>>Height>>Width;
    
    cout<<"The length you are looking for is. "<<endl;
    Length= Area/Width; 
    cout<<Length;

        
    cout<<"Good-bye"<<endl;
     
    
    //Output the processed Data
    
    //Exit Stage Right!
    return 0;
}
